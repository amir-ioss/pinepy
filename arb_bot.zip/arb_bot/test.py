import ccxt
import json
import time

# Create a Binance instance
binance = ccxt.binance()

# pairs = json.loads(open("pairs.json", "r").read())
# core = []
# for pair in pairs:
#     tk1 = pair.split("/")[0]
#     if(tk1 not in core):
#         core.append(tk1)
# print(core)

def delay(ms):
    # No need for 'await' since this function is not asynchronous
    time.sleep(ms / 1000)

def make_request_with_rate_limit(api_function, delay_between_requests):
    # Implement your rate-limiting logic here
    # For example, you may want to track the time of the last request and wait if needed
    delay(delay_between_requests)

    # Make the API request
    return api_function()

def get_all_pair_combinations():
    try:
        # Load markets to ensure we have the latest market information
        # exchange_info = binance.load_markets()
        # exchange_info = json.loads(open("output.json", "r").read())
        # Extract all trading pairs from exchange_info
        # all_pairs = [symbol['symbol'] for symbol in exchange_info.values() if symbol.get('active')]
        # Write the JSON string to the file
        # with open("pairs.json", "w") as file:
        #     json.dump(all_pairs, file, indent=2)

        pairs = json.loads(open("pairs.json", "r").read())
        core = json.loads(open("core.json", "r").read())
        pairs_by_base_asset = {}

        # for my_coin in core:
        for my_coin in ["USDT"]:
            print('---------------------------', my_coin)

            for symbol in pairs:
                if symbol.split("/")[1] == my_coin:
                    for symbol2 in pairs:
                        if symbol.split("/")[0] == symbol2.split("/")[1]:
                            for symbol3 in pairs:
                                if symbol3 == symbol2.split("/")[0] + "/" + my_coin:
                                    find_triangular_arbitrage_opportunity(symbol, symbol2, symbol3)

    except Exception as error:
        print("Error fetching and processing exchange_info:", str(error))

def find_triangular_arbitrage_opportunity(symbol1, symbol2, symbol3):
    try:
        # Specify a valid trading pair for the triangular arbitrage
        trading_pair1 = symbol1
        trading_pair2 = symbol2
        trading_pair3 = symbol3

        # Fetch ticker information for the specified trading pairs
        ticker1 = make_request_with_rate_limit(lambda: binance.fetch_ticker(trading_pair1), 300)
        ticker2 = make_request_with_rate_limit(lambda: binance.fetch_ticker(trading_pair2), 300)
        ticker3 = make_request_with_rate_limit(lambda: binance.fetch_ticker(trading_pair3), 300)

        # Calculate the potential profit from the triangular arbitrage
        arbitrage_profit = calculate_triangular_arbitrage_profit(ticker1, ticker2, ticker3)
        if arbitrage_profit > 0.005:
            # Print the results
            print("Arbitrage Opportunity:")
            print(f"- Buy {trading_pair1}: {ticker1['ask']}")
            print(f"- Sell {trading_pair2}: {ticker2['bid']}")
            print(f"- Buy {trading_pair3}: {ticker3['ask']}")
            print(f"Potential Profit: {arbitrage_profit}")

            # Open the file in append mode
            with open("example_2_.txt", "a") as file:
                file.write("Arbitrage Opportunity:\n")
                file.write(f"- Buy {trading_pair1}: {ticker1['ask']}\n")
                file.write(f"- Sell {trading_pair2}: {ticker2['bid']}\n")
                file.write(f"- Buy {trading_pair3}: {ticker3['ask']}\n")
                file.write(f"Potential Profit: {arbitrage_profit}\n\n")
                # Append text to the file
        else:
            print(symbol1, symbol2, symbol3)
    except Exception as error:
        print("Error:", str(error))

def calculate_triangular_arbitrage_profit(ticker1, ticker2, ticker3):
    # Calculate the potential profit from triangular arbitrage
    # Formula: Profit = (1 / ticker1['ask']) * (1 / ticker2['bid']) * ticker3['ask'] - 1

    rate1 = 1 / ticker1['ask']
    rate2 = 1 / ticker2['bid']
    rate3 = ticker3['ask']

    profit = rate1 * rate2 * rate3 - 1
    return profit

# Call the function to get combinations for all trading pairs
get_all_pair_combinations()
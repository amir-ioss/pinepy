const ccxt = require("ccxt");
const fs = require("fs");

// Create a Binance instance
const binance = new ccxt.binance();

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function makeRequestWithRateLimit(apiFunction, delayBetweenRequests) {
  // Implement your rate-limiting logic here
  // For example, you may want to track the time of the last request and wait if needed
  await delay(delayBetweenRequests);

  // Make the API request
  return apiFunction();
}

async function getAllPairCombinations() {
  try {
    // Load markets to ensure we have the latest market information
    // const exchangeInfo = await binance.loadMarkets();
    // const exchangeInfo = require("./output.json");
    // Extract all trading pairs from exchangeInfo
    // const allPairs = Object.values(exchangeInfo).filter(symbol => symbol?.active).map((symbol) => symbol.symbol);
    // Write the JSON string to the file
    // fs.writeFileSync("pairs.json", JSON.stringify(allPairs, null, 2), "utf-8");

    const pairs = require("./pairs.json");
    var pairsByBaseAsset = {};

    // ['BTC/USDT', 'ETH/BTC', 'USDT/ETH'];
    // ['BTC/USDT', 'ETH/BTC', 'ETH/USDT'];
    pairs.forEach((coin, index) => {
      if (index > 2) return;
      const myCoin = coin.split("/")[0];
      // const myCoin = "DAI";
      console.log('---------------------------', myCoin);
      pairs.forEach((symbol, idx) => {
        // if(idx > 11)return
        if (symbol.split("/")[1] == myCoin) {
          // console.log(symbol);
          // STEP 2
          pairs.forEach((symbol2) => {
            if (symbol.split("/")[0] == symbol2.split("/")[1]) {
              // console.log(symbol, symbol2);

              pairs.forEach((symbol3) => {
                if (symbol3 == symbol2.split("/")[0] + "/" + myCoin) {
                  // console.log('---', symbol3);
                  // console.log("pairs- ", symbol, symbol2, symbol3);
                  // console.log("---------------");
                  // pairsByBaseAsset[[symbol+symbol2+symbol3]] = [symbol, symbol2, symbol3]
                  findTriangularArbitrageOpportunity(symbol, symbol2, symbol3);
                }
              });
            }
          });
        }
      });
    }); //start
    // console.log(pairsByBaseAsset);
  } catch (error) {
    console.error("Error fetching and processing exchangeInfo:", error.message);
  }
}

// Call the function to get combinations for all trading pairs
getAllPairCombinations();

async function findTriangularArbitrageOpportunity(symbol1, symbol2, symbol3) {
  try {
    // Create an instance of the Binance exchange

    // Specify a valid trading pair for the triangular arbitrage
    // const tradingPair1 = "ETH/BTC";
    // const tradingPair2 = "BTC/USDT";
    // const tradingPair3 = "ETH/USDT";

    const tradingPair1 = symbol1;
    const tradingPair2 = symbol2;
    const tradingPair3 = symbol3;

    // Fetch ticker information for the specified trading pairs
    // const ticker1 = await binance.fetchTicker(tradingPair1);
    // const ticker2 = await binance.fetchTicker(tradingPair2);
    // const ticker3 = await binance.fetchTicker(tradingPair3);

    const ticker1 = await makeRequestWithRateLimit(
      () => binance.fetchTicker(tradingPair1),
      300
    );
    const ticker2 = await makeRequestWithRateLimit(
      () => binance.fetchTicker(tradingPair2),
      300
    );
    const ticker3 = await makeRequestWithRateLimit(
      () => binance.fetchTicker(tradingPair3),
      300
    );

    // Calculate the potential profit from the triangular arbitrage
    const arbitrageProfit = calculateTriangularArbitrageProfit(
      ticker1,
      ticker2,
      ticker3
    );
    if (arbitrageProfit > 0.005) {
      // Print the results
      console.log(`Arbitrage Opportunity:`);
      console.log(`- Buy ${tradingPair1}: ${ticker1.ask}`);
      console.log(`- Sell ${tradingPair2}: ${ticker2.bid}`);
      console.log(`- Buy ${tradingPair3}: ${ticker3.ask}`);
      console.log(`Potential Profit: ${arbitrageProfit}`);
    } else {
      console.log(symbol1, symbol2, symbol3);
    }
  } catch (error) {
    console.error("Error:", error.message);
  }
}

function calculateTriangularArbitrageProfit(ticker1, ticker2, ticker3) {
  // Calculate the potential profit from triangular arbitrage
  // Formula: Profit = (1 / ticker1.ask) * (1 / ticker2.bid) * ticker3.ask - 1

  const rate1 = 1 / ticker1.ask;
  const rate2 = 1 / ticker2.bid;
  const rate3 = ticker3.ask;

  const profit = rate1 * rate2 * rate3 - 1;
  return profit;
}
// Call the function to find triangular arbitrage opportunity
// findTriangularArbitrageOpportunity();
